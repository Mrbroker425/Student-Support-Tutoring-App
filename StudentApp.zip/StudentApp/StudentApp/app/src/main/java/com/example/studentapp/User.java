package com.example.studentapp;

public class User {
    private String StudentNumber;
    private String password;

    public User(String StudentNumber, String password) {
        this.StudentNumber = StudentNumber;
        this.password = password;
    }

    public String getStudentNumber() {
        return StudentNumber;
    }

    public void setStudentNumber(String studentNumber) {
        this.StudentNumber = studentNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

