package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class AdminPayment extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    private EditText emailEditText, fullNameEditText, yearOfEmploymentEditText, amountEditText;
    private Button payButton;

    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_payment);

        emailEditText = findViewById(R.id.TutorEmail);
        fullNameEditText = findViewById(R.id.TutorName);
        yearOfEmploymentEditText = findViewById(R.id.Year_of_employement);
        amountEditText = findViewById(R.id.Amount_pay);
        payButton = findViewById(R.id.btnPay);
        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        databaseReference = FirebaseDatabase.getInstance().getReference("users");

        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String fullName = fullNameEditText.getText().toString().trim();
                String yearOfEmployment = yearOfEmploymentEditText.getText().toString().trim();
                String amount = amountEditText.getText().toString().trim();

                if (email.isEmpty() || fullName.isEmpty() || yearOfEmployment.isEmpty() || amount.isEmpty()) {
                    Toast.makeText(AdminPayment.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                validateAndSendEmail(email, fullName, yearOfEmployment, amount);
            }


            private void validateAndSendEmail(String email, String fullName, String yearOfEmployment, String amount) {
                Query tutorQuery = databaseReference.orderByChild("email").equalTo(email);
                tutorQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            // Tutor email found in the database
                            String message = "Dear " + fullName + ",\n\n" +
                                    "This is to notify you that you have been paid an amount of R" + amount + ".\n" +
                                    "Year of Employment: " + yearOfEmployment + "\n\n" +
                                    "Thank you,\n" +
                                    "Admin";
                            sendmail("Payment Notification", message, email);
                        } else {
                            Toast.makeText(AdminPayment.this, "No tutor found with this email", Toast.LENGTH_SHORT).show();
                        }
                    }

                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(AdminPayment.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

                navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        int itemId = item.getItemId();

                        if (itemId == R.id.navHome) {
                            Intent intetn = new Intent(getApplicationContext(), admin_notifications.class);
                            startActivity(intetn);
                            Toast.makeText(AdminPayment.this, "Home", Toast.LENGTH_SHORT).show();
                        }
                        if (itemId == R.id.navPayment) {
                            Intent intetn = new Intent(getApplicationContext(), AdminPayment.class);
                            startActivity(intetn);
                            Toast.makeText(AdminPayment.this, "Tutor Payment", Toast.LENGTH_SHORT).show();
                        }
                        if (itemId == R.id.navSalary) {
                            Intent intetn = new Intent(getApplicationContext(), AdminBudget.class);
                            startActivity(intetn);
                            Toast.makeText(AdminPayment.this, "Budget", Toast.LENGTH_SHORT).show();
                        }
                        if (itemId == R.id.navNotification) {
//                    Intent intetn = new Intent(getApplicationContext(), .class);
//                    startActivity(intetn);
                            Toast.makeText(AdminPayment.this, "Notification", Toast.LENGTH_SHORT).show();
                        }
                        if (itemId == R.id.navlogout) {
                            Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                            startActivity(intetn);
                            Toast.makeText(AdminPayment.this, "Logged out", Toast.LENGTH_SHORT).show();
                        }
                        drawerLayout.close();
                        return false;
                    }
                });
            }



            public void sendmail(String Subject, String content, String to_email) {
                Intent intent = new Intent(new Intent(Intent.ACTION_SEND));
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to_email});
                intent.putExtra(Intent.EXTRA_SUBJECT, Subject);
                intent.putExtra(Intent.EXTRA_TEXT, content);
                intent.setType("message/rfc822");
                startActivity(Intent.createChooser(intent, "Choose email Client: "));
            }
        });
    }
}
