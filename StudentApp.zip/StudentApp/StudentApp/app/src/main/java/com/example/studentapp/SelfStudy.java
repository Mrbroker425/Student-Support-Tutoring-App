package com.example.studentapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class SelfStudy extends AppCompatActivity {
    Button BroCode, FreeCodeCamp, Mosh;
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study);

        BroCode = (Button) findViewById(R.id.BroCodeButton);
        FreeCodeCamp = (Button) findViewById(R.id.FreeCodeCampButton);
        Mosh = (Button) findViewById(R.id.ProgrammingWithMoshButton);

        BroCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.youtube.com/@BroCodez";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        FreeCodeCamp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.freecodecamp.org/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        Mosh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.youtube.com/@programmingwithmosh";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Stud_study);


        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                   Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                   startActivity(intetn);
                    Toast.makeText(SelfStudy.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                   //tutor Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    //startActivity(intetn);
                    Toast.makeText(SelfStudy.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(SelfStudy.this, "Self Study", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(SelfStudy.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }
//                if (itemId == R.id.navFeedback) {
//                    Toast.makeText(SelfStudy.this, "Feedback", Toast.LENGTH_SHORT).show();
//                }
                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(SelfStudy.this, "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });

    }
}