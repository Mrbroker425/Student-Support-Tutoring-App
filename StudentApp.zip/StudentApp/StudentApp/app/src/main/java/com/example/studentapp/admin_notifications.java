package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class admin_notifications extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;

    private TextView tutorCountTextView;
    private TextView studentCountTextView;
    private ListView listView;

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference usersReference;

    private List<String> tutorNames;
    private List<String> studentNames;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_notifications);

        tutorCountTextView = findViewById(R.id.tutorCountTextView);
        studentCountTextView = findViewById(R.id.studentCountTextView);
        listView = findViewById(R.id.listView);

        firebaseDatabase = FirebaseDatabase.getInstance();
        usersReference = firebaseDatabase.getReference("users");

        tutorNames = new ArrayList<>();
        studentNames = new ArrayList<>();

        loadUserCounts();

        tutorCountTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNames(tutorNames);
            }
        });

        studentCountTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNames(studentNames);
            }
        });


        drawerLayout = findViewById(R.id.drawerLayout_admin_Notifications);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Admin_notification);

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();

            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), admin_notifications.class);
                    startActivity(intetn);
                    Toast.makeText(admin_notifications.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navPayment) {
                    Intent intetn = new Intent(getApplicationContext(), TutorPayment.class);
                    startActivity(intetn);
                    Toast.makeText(admin_notifications.this, "Tutor Payment", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSalary) {
                    Intent intetn = new Intent(getApplicationContext(), AdminBudget.class);
                    startActivity(intetn);
                    Toast.makeText(admin_notifications.this, "Budget", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navNotification) {
//                    Intent intetn = new Intent(getApplicationContext(), .class);
//                    startActivity(intetn);
                    Toast.makeText(admin_notifications.this, "Notification", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(admin_notifications.this, "Logged out", Toast.LENGTH_SHORT).show();
                }
                drawerLayout.close();
                return false;
            }
        });
    }

    private void loadUserCounts() {
        usersReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tutorCount = 0;
                int studentCount = 0;

                tutorNames.clear();
                studentNames.clear();

                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    String accountType = userSnapshot.child("accountType").getValue(String.class);
                    String fullName = userSnapshot.child("fullName").getValue(String.class);

                    if ("Tutor".equals(accountType)) {
                        tutorCount++;
                        tutorNames.add(fullName);
                    } else if ("Student".equals(accountType)) {
                        studentCount++;
                        studentNames.add(fullName);
                    }
                }

                tutorCountTextView.setText("Tutors: " + tutorCount);
                studentCountTextView.setText("Students: " + studentCount);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(admin_notifications.this, "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayNames(List<String> names) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names);
        listView.setAdapter(adapter);
    }
}

