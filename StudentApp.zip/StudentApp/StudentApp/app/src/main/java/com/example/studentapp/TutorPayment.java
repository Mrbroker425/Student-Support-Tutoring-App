package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class TutorPayment extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;

    TextView FromTime, FromSelectedTime, ToTime, ToSelectedTime;

    EditText email, rateperhour, hoursworked, From, to, ValueofClaim;
    Button submitBtn;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_payment);
        drawerLayout = findViewById(R.id.drawerLayout_tutor_payment);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Tut_Payment);

        email = (EditText) findViewById(R.id.tutor_Email);
        rateperhour = (EditText) findViewById(R.id.Rate_per_hour);
        hoursworked = (EditText) findViewById(R.id.TotalHouorsWorkedperDay);

        FromTime = findViewById(R.id.Fromtime);
        FromSelectedTime = findViewById(R.id.selectedFromTime);

        ToTime = findViewById(R.id.Totime);
        ToSelectedTime = findViewById(R.id.selectedToTime);

        ValueofClaim = (EditText) findViewById(R.id.ValueOfClaim);
        submitBtn = (Button) findViewById(R.id.btnSubmit_Form);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("users");

        FromTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePickerDialog();
            }

            private void showTimePickerDialog() {
                TimePickerFragmentPayment newFragmentFrom = new TimePickerFragmentPayment();
                newFragmentFrom.show(getSupportFragmentManager(), "time picker");
            }
        });

        ToTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePickerDialog();
            }

            private void showTimePickerDialog() {
                TimePickerFragmentpayment2 newFragmentTo = new TimePickerFragmentpayment2();
                newFragmentTo.show(getSupportFragmentManager(), "time picker");
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener() {

            String TutorEmail = email.getText().toString();
            String rates = rateperhour.getText().toString();
            String hours = hoursworked.getText().toString();

            String ClaimValue = ValueofClaim.getText().toString();
            @Override
            public void onClick(View v) {
                String selectedFromTimeText = FromSelectedTime.getText().toString();
                String selectedToTimeText = ToSelectedTime.getText().toString();
                String message ="Dear Admin \nI work at a rate per hour of: " + rates +
                        "\nI have worked a total of " + hours + " per day from " + FromSelectedTime +
                        " to " + ToSelectedTime + ". Which brings my Claim to the value of: R" + ValueofClaim +
                        "\n\nRegards.";

                FirebaseUser user = mAuth.getCurrentUser();
                Query tutorQuery = mDatabase.orderByChild("accountType").equalTo("Admin");
                tutorQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot tutorSnapshot : dataSnapshot.getChildren()) {
                                UserModel tutor = tutorSnapshot.getValue(UserModel.class);
                                if (tutor != null && tutor.email != null) {
                                    String tutorEmail = tutor.email;
                                    sendmail("Claim Form Submission", message, tutorEmail);
                                    break;
                                }
                            }
                        } else {
                            Toast.makeText(TutorPayment.this, "No tutor found in the database.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(TutorPayment.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
    });
        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intetn);
                    Toast.makeText(TutorPayment.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                    Intent intetn = new Intent(getApplicationContext(), TutorRequest.class);
                    startActivity(intetn);
                    Toast.makeText(TutorPayment.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(TutorPayment.this, "Self Study", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(TutorPayment.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }
//                if (itemId == R.id.navFeedback) {
//                    Toast.makeText(TutorRequest.this, "Feedback", Toast.LENGTH_SHORT).show();
//                }
                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(TutorPayment.this, "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });
    }

    public void updateFromTime(int hourOfDay, int minute) {
        String formattedTime = String.format(Locale.US,"%02d:%02d",hourOfDay,minute);
        FromSelectedTime.setText("Time: "+formattedTime);
        Toast.makeText(this, formattedTime, Toast.LENGTH_SHORT).show();
    }

    public void updateToTime(int hourOfDay, int minute) {
        String formattedTime = String.format(Locale.US,"%02d:%02d",hourOfDay,minute);
        ToSelectedTime.setText("Time: "+formattedTime);
        Toast.makeText(this, formattedTime, Toast.LENGTH_SHORT).show();
    }

    public void sendmail(String Subject, String content, String to_email){
        Intent intent = new Intent(new Intent(Intent.ACTION_SEND));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to_email});
        intent.putExtra(Intent.EXTRA_SUBJECT, Subject);
        intent.putExtra(Intent.EXTRA_TEXT, content);
        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose email Client: "));
    }
}