package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.functions.FirebaseFunctions;
//import com.google.firebase.functions.HttpsCallableResult;

//import java.util.HashMap;
//import java.util.Map;

public class Signuppage extends AppCompatActivity {

    private EditText signupFullName, signupUsername, signupEmail, signupPassword;
    private Spinner accountTypeSpinner;
    private Button signupButton;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    //private FirebaseFunctions mFunctions;

    private TextView loginRedirectText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signuppage);

        // Initialize Firebase Auth and Database Reference
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();
       // mFunctions = FirebaseFunctions.getInstance();

        signupFullName = findViewById(R.id.signup_name);
        signupUsername = findViewById(R.id.signUp_username);
        signupEmail = findViewById(R.id.signup_email);
        signupPassword = findViewById(R.id.signup_password);
        accountTypeSpinner = findViewById(R.id.account_type_spinner);
        signupButton = findViewById(R.id.signupButton);
        loginRedirectText = findViewById(R.id.loginRedirectText);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });

        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Loginpage.class);
                startActivity(intent);
                finish();
            }
        });


    }

    private void createAccount() {
        String fullName = signupFullName.getText().toString().trim();
        String username = signupUsername.getText().toString().trim();
        String email = signupEmail.getText().toString().trim();
        String password = signupPassword.getText().toString().trim();
        String accountType = accountTypeSpinner.getSelectedItem().toString();

        if (TextUtils.isEmpty(fullName)) {
            signupFullName.setError("Full Name is required.");
            return;
        }

        if (TextUtils.isEmpty(username)) {
            signupUsername.setError("Username is required.");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            signupEmail.setError("Email is required.");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            signupPassword.setError("Password is required.");
            return;
        }

        if (password.length() < 6) {
            signupPassword.setError("Password must be at least 6 characters.");
            return;
        }

        // Check if mAuth and mDatabase are initialized
        if (mAuth == null && mDatabase == null) {
            Toast.makeText(Signuppage.this, "Firebase not initialized.", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(Signuppage.this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            // Save user information in the database
                            String userId = user.getUid();
                            User newUser = new User(fullName, username, email, accountType);
                            mDatabase.child("users").child(userId).setValue(newUser)
                                    .addOnCompleteListener(Signuppage.this, task1 -> {
                                        if (task1.isSuccessful()) {
                                            Toast.makeText(Signuppage.this, "Account created successfully.", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(Signuppage.this, Loginpage.class);
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            Toast.makeText(Signuppage.this, "Failed to save user information.", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    } else {
                        if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                            Toast.makeText(Signuppage.this, "User already exists.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Signuppage.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    public static class User {
        public String fullName;
        public String username;
        public String email;
        public String accountType;

        public User() {}

        public User(String fullName, String username, String email, String accountType) {
            this.fullName = fullName;
            this.username = username;
            this.email = email;
            this.accountType = accountType;
        }
    }

}
