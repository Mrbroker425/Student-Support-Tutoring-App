package com.example.studentapp;

import java.util.Date;

public class SimpleDateFormat {

        public SimpleDateFormat(String s) {
        }

        public Date format(Date time) {

            return time;
        }

}
