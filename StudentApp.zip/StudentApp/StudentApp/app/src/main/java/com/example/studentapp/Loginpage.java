package com.example.studentapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Loginpage extends AppCompatActivity {
    TextView forgotPasswordTextView;
    private EditText login_email, login_password;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    Button loginButton;
    TextView signupRedirectText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        forgotPasswordTextView = findViewById(R.id.forgot_password_text_view);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("users");

        // Set the text color of the "Forgot password?" text view to blue
        forgotPasswordTextView.setTextColor(Color.BLUE);
        // Set the text size of the "Forgot password?" text view to 16sp
        forgotPasswordTextView.setTextSize(16);
        // Set the "Remember me" checkbox to be checked by default

        login_email = findViewById(R.id.login_studentNumber);
        login_password = findViewById(R.id.login_password);
        loginButton = findViewById(R.id.loginButton);
        signupRedirectText = findViewById(R.id.signupRedirectText);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });

        signupRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Loginpage.this, Signuppage.class);
                startActivity(intent);
            }
        });

        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetPassword();
            }
        });
    }

    private void loginUser() {
        String email = login_email.getText().toString().trim();
        String password = login_password.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            login_email.setError("Email is required.");
            return;
        }

        if (TextUtils.isEmpty(password)) {
            login_password.setError("Password is required.");
            return;
        }

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            checkUserType(user.getUid());
                        }
                    } else {
                        Toast.makeText(Loginpage.this, "Authentication failed.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void checkUserType(String userId) {
        mDatabase.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String accountType = snapshot.child("accountType").getValue(String.class);
                    if (accountType != null) {
                        switch (accountType) {
                            case "Admin":
                                startActivity(new Intent(Loginpage.this, AdminDashboard.class));
                                break;
                            case "Student":
                                startActivity(new Intent(Loginpage.this, MainActivity.class));
                                break;
                            case "Tutor":
                                startActivity(new Intent(Loginpage.this, TutorDashboard.class));
                                break;
                            default:
                                Toast.makeText(Loginpage.this, "Account type not recognized.", Toast.LENGTH_SHORT).show();
                                break;
                        }
                        finish();
                    } else {
                        Toast.makeText(Loginpage.this, "Account type not found.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(Loginpage.this, "User data not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Loginpage.this, "Failed to read user data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetPassword() {
        String email = login_email.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            login_email.setError("Email is required to reset password.");
            return;
        }

        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(Loginpage.this, "Password reset email sent.",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Loginpage.this, "Failed to send password reset email.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
