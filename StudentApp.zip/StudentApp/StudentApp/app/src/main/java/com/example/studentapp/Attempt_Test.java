package com.example.studentapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Attempt_Test extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    Button quizletBtn, freeCodeCampBtn, CourseraBtn, codeacademyBtn, attemptquiz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_attempt_test);

        quizletBtn = (Button) findViewById(R.id.Quizlet);
        freeCodeCampBtn = (Button) findViewById(R.id.FreeCodeCampButton);
        CourseraBtn = (Button) findViewById(R.id.Coursera);
        codeacademyBtn = (Button) findViewById(R.id.CodeAcademy);
        //attemptquiz = (Button) findViewById(R.id.AttemptTheQuizes);

        quizletBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://quizlet.com/gb";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        freeCodeCampBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.freecodecamp.org/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        CourseraBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.coursera.org/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        codeacademyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.codecademy.com/?g_network=g&g_productchannel=&g_adid=528849219280&g_locinterest=&g_keyword=codecademy&g_acctid=243-039-7011&g_adtype=&g_keywordid=kwd-41065460761&g_ifcreative=&g_campaign=account&g_locphysical=1028709&g_adgroupid=70492864474&g_productid=&g_source={sourceid}&g_merchantid=&g_placement=&g_partition=&g_campaignid=1726903838&g_ifproduct=&utm_id=t_kwd-41065460761:ag_70492864474:cp_1726903838:n_g:d_c&utm_source=google&utm_medium=paid-search&utm_term=codecademy&utm_campaign=INTL_Brand_Exact&utm_content=528849219280&g_adtype=search&g_acctid=243-039-7011&gad_source=1&gclid=CjwKCAjwo6GyBhBwEiwAzQTmc9nHt5P_7vlOKhMLsgPrVuI-dhFCX4sTB9I1W8N7KQlAliqRdEfSnhoCaMIQAvD_BwE";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Attempt_Test);

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();

            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intetn);
                    Toast.makeText(Attempt_Test.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                    //tutor Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    //startActivity(intetn);
                    Toast.makeText(Attempt_Test.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(Attempt_Test.this, "Self Study", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(Attempt_Test.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(Attempt_Test.this, "Logged out", Toast.LENGTH_SHORT).show();
                }
                drawerLayout.close();
                return false;
            }
        });

    }
}