package com.example.studentapp;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
     Button LocationButton;
     Button RateusButton;
     Button SmsButton;
     Button SelfstudyButton;
     Button BookATutorButton;
     Button TestButton, FeedbackButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BookATutorButton = findViewById(R.id.BookTutorialButton);
        BookATutorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TutorRequest.class);
                startActivity(intent);
            }
        });

        SelfstudyButton = findViewById(R.id.SelfstudyButton);
        SelfstudyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SelfStudy.class);
                startActivity(intent);
            }
        });

        TestButton = findViewById(R.id.TestButton);
        TestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Attempt_Test.class);
                startActivity(intent);
            }
        });

        FeedbackButton = findViewById(R.id.FeedbackButton);
        FeedbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Feedback.class);
                startActivity(intent);
            }
        });


        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView);


        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();

            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intetn);
                    Toast.makeText(MainActivity.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                    Intent intetn = new Intent(getApplicationContext(), TutorRequest.class);
                    startActivity(intetn);
                    Toast.makeText(MainActivity.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(MainActivity.this, "Self Study", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(MainActivity.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(MainActivity.this, "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });

    }
}
