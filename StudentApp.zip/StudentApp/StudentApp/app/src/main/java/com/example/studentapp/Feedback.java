package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class Feedback extends AppCompatActivity {

    private RatingBar ratingQuality, ratingClarity, ratingRelevance, ratingPacing;
    private RadioGroup radioEasyToFollow, radioTopicsCovered;
    private EditText editDifficultConcepts;
    private Button submitFeedbackButton;
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        ratingQuality = findViewById(R.id.ratingQuality);
        ratingClarity = findViewById(R.id.ratingClarity);
        ratingRelevance = findViewById(R.id.ratingRelevance);
        ratingPacing = findViewById(R.id.ratingPacing);
        radioEasyToFollow = findViewById(R.id.radioEasyToFollow);
        radioTopicsCovered = findViewById(R.id.radioTopicsCovered);
        editDifficultConcepts = findViewById(R.id.editDifficultConcepts);
        submitFeedbackButton = findViewById(R.id.submitFeedbackButton);

        drawerLayout = findViewById(R.id.drawerLayout_student_feedback);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Student_Feedback);

        submitFeedbackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float qualityRating = ratingQuality.getRating();
                float clarityRating = ratingClarity.getRating();
                float relevanceRating = ratingRelevance.getRating();
                float pacingRating = ratingPacing.getRating();
                boolean easyToFollow = getEasyToFollow();
                boolean topicsCovered = getTopicsCovered();
                String difficultConcepts = editDifficultConcepts.getText().toString();

                // You can handle the ratings, boolean values, and text input here
                // For now, just display a toast message with the feedback data
                String feedbackMessage = "Quality Rating: " + qualityRating +"\nClarity Rating: " + clarityRating +
                        "\nRelevance Rating: " + relevanceRating +
                        "\nPacing Rating: " + pacingRating +
                        "\nEasy to Follow: " + (easyToFollow ? "Yes" : "No") +
                        "\nTopics Covered: " + (topicsCovered ? "Yes" : "No") ;
                Toast.makeText(Feedback.this, feedbackMessage, Toast.LENGTH_LONG).show();
            }
        });

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();

            }
        });

        View headerView = navigationView.getHeaderView(0);


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intetn);
                    Toast.makeText(Feedback.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                    Intent intetn = new Intent(getApplicationContext(), TutorRequest.class);
                    startActivity(intetn);
                    Toast.makeText(Feedback.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(Feedback.this, "Self Study", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(Feedback.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(Feedback.this, "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });

    }

    private boolean getEasyToFollow() {
        int selectedId = radioEasyToFollow.getCheckedRadioButtonId();
        return selectedId == R.id.radioYes;
    }

    private boolean getTopicsCovered() {
        int selectedId = radioTopicsCovered.getCheckedRadioButtonId();
        return selectedId == R.id.radioExpected;
    }
}