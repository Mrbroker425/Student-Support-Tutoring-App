//package com.example.studentapp;
//
//import android.graphics.drawable.ColorDrawable;
//import android.os.Bundle;
//
//import androidx.activity.EdgeToEdge;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.graphics.Insets;
//import androidx.core.view.ViewCompat;
//import androidx.core.view.WindowInsetsCompat;
//
//public class ratings extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_ratings);
//        RateUsDialog rateUsDialog=new RateUsDialog(ratings.this);
//        rateUsDialog.getWindow().setBackgroundDrawable(new ColorDrawable(getResources().getColor(android.R.color.transparent)));
//        rateUsDialog.setCancelable(false);
//        rateUsDialog.show();
//    }
//}