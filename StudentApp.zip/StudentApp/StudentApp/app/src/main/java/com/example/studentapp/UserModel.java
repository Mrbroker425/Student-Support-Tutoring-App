package com.example.studentapp;

public class UserModel {
    public String email;
    public String accountType;

    public UserModel() {
        // Default constructor required for calls to DataSnapshot.getValue(UserModel.class)
    }

    public UserModel(String email, String accountType) {
        this.email = email;
        this.accountType = accountType;
    }
}
