package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminBudget extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    private EditText budgetEditText;
    private Button saveButton;

    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_budget);

        budgetEditText = findViewById(R.id.budgetEditText);
        saveButton = findViewById(R.id.saveButton);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("budgets");

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveBudget();
            }
        });

        drawerLayout = findViewById(R.id.drawerLayout_admin_budget);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Admin_Budget);

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), admin_notifications.class);
                    startActivity(intetn);
                    Toast.makeText(AdminBudget.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navPayment) {
                    Intent intetn = new Intent(getApplicationContext(), TutorPayment.class);
                    startActivity(intetn);
                    Toast.makeText(AdminBudget.this, "Tutor Payment", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSalary) {
                    Intent intetn = new Intent(getApplicationContext(), AdminBudget.class);
                    startActivity(intetn);
                    Toast.makeText(AdminBudget.this, "Budget", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navNotification) {
//                    Intent intetn = new Intent(getApplicationContext(), .class);
//                    startActivity(intetn);
                    Toast.makeText(AdminBudget.this, "Notification", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(AdminBudget.this, "Logged out", Toast.LENGTH_SHORT).show();
                }
                drawerLayout.close();
                return false;
            }
        });

    }

    private void saveBudget() {
        String budget = budgetEditText.getText().toString().trim();

        if (TextUtils.isEmpty(budget)) {
            Toast.makeText(this, "Please enter a budget", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = databaseReference.push().getKey();
        databaseReference.child(id).setValue(budget);

        Toast.makeText(this, "Budget saved", Toast.LENGTH_SHORT).show();
        budgetEditText.setText("");
    }

}