package com.example.studentapp;

public class TutorRequestModel {
    public String userEmail;
    public String subject;
    public String date;
    public String time;

    public TutorRequestModel() {
        // Default constructor required for calls to DataSnapshot.getValue(TutorRequestModel.class)
    }

    public TutorRequestModel(String userEmail, String subject, String date, String time) {
        this.userEmail = userEmail;
        this.subject = subject;
        this.date = date;
        this.time = time;
    }
}

