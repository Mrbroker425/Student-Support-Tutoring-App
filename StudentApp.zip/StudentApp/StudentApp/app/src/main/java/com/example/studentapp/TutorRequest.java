package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.studentapp.R;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class TutorRequest extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private TextView requestTutor, Module;
    private RadioGroup rdgClassType;
    private RadioButton mobile, programming, software, information;
    private TextView date, selectedDate, time, selectedTime, location;
    private Button btnSubmit;
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_request);

        requestTutor = findViewById(R.id.requestTutor);
        Module = findViewById(R.id.Module);
        rdgClassType = findViewById(R.id.rdgClassType);
        mobile = findViewById(R.id.mobile);
        programming = findViewById(R.id.programming);
        software = findViewById(R.id.software);
        information = findViewById(R.id.information);
        date = findViewById(R.id.date);
        selectedDate = findViewById(R.id.selectedDate);
        time = findViewById(R.id.time);
        selectedTime = findViewById(R.id.selectedTime);
        btnSubmit = findViewById(R.id.btnSubmit);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("users");
        location = (EditText) findViewById(R.id.tutor_location);


//        btnSubmit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(TutorRequest.this, "Submitted successfully", Toast.LENGTH_SHORT).show();
//            }
//        });
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePickerDialog();
            }

            private void showTimePickerDialog() {
                TimePickerFragment newFragment = new TimePickerFragment();
                newFragment.show(getSupportFragmentManager(), "time picker");
            }
        });

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePickerDiaog();
            }

            public void updateDate(int year, int month, int day) {
                String selectedDate = day + "/" + (month + 1) + "/" + year;
                Toast.makeText(getApplicationContext(), "Date:" + selectedDate, Toast.LENGTH_SHORT).show();

            }

            public void showDatePickerDiaog() {
                datePicker newFragment = new datePicker();
                newFragment.show(getSupportFragmentManager(), "Date Picker");

            }

        });


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = rdgClassType.getCheckedRadioButtonId();
                if (selectedId == -1) {
                    Toast.makeText(TutorRequest.this, "Please select a subject", Toast.LENGTH_SHORT).show();
                } else if(selectedId >= 0) {
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedSubject = selectedRadioButton.getText().toString();
                    String selectedDateText = selectedDate.getText().toString();
                    String selectedTimeText = selectedTime.getText().toString();
                    String tutLocation = location.getText().toString().trim().toUpperCase();
                    String message = "Selected subject: " + selectedSubject + "\nSelected date : " + selectedDateText + "\nSelected time: " + selectedTimeText + "\nLocation: " + tutLocation;
                    Toast.makeText(TutorRequest.this, message, Toast.LENGTH_LONG).show();

                    FirebaseUser user = mAuth.getCurrentUser();

                        TutorRequestModel request = new TutorRequestModel(user.getEmail(), selectedSubject, selectedDateText, selectedTimeText);
                        mDatabase.push().setValue(request);

                        // Query to find a user with account type "Tutor"
                        Query tutorQuery = mDatabase.orderByChild("accountType").equalTo("Tutor");
                        tutorQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    for (DataSnapshot tutorSnapshot : dataSnapshot.getChildren()) {
                                        UserModel tutor = tutorSnapshot.getValue(UserModel.class);
                                        if (tutor != null && tutor.email != null) {
                                            String tutorEmail = tutor.email;
                                            sendmail("New Tutor Request", message, tutorEmail);
                                            break;
                                        }
                                    }
                                } else {
                                    Toast.makeText(TutorRequest.this, "No tutor found in the database.", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(TutorRequest.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                    } else {
                        Toast.makeText(TutorRequest.this, "User not logged in.", Toast.LENGTH_SHORT).show();
                    }

            }
        });

        drawerLayout = findViewById(R.id.drawerLayout_tutor_request);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Tut_Request);


        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intetn);
                    Toast.makeText(TutorRequest.this, "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navTutor) {
                    Intent intetn = new Intent(getApplicationContext(), TutorRequest.class);
                    startActivity(intetn);
                    Toast.makeText(TutorRequest.this, "Book a Tutor", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navSelfStudy) {
                    Intent intetn = new Intent(getApplicationContext(), SelfStudy.class);
                    startActivity(intetn);
                    Toast.makeText(TutorRequest.this, "Self Study", Toast.LENGTH_SHORT).show();
                }

                if (itemId == R.id.navTest) {
                    Intent intetn = new Intent(getApplicationContext(), Attempt_Test.class);
                    startActivity(intetn);
                    Toast.makeText(TutorRequest.this, "Attempt a Test", Toast.LENGTH_SHORT).show();
                }
//                if (itemId == R.id.navFeedback) {
//                    Toast.makeText(TutorRequest.this, "Feedback", Toast.LENGTH_SHORT).show();
//                }

                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(TutorRequest.this, "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });

    }
    public void updateDate(int year, int month, int dayOfMonth) {
        String selectedFormatDate = dayOfMonth + "/"+ (month+1)+"/"+year;
        selectedDate.setText("Date: " + selectedFormatDate);
        Toast.makeText(getApplicationContext(), "Date:" + selectedDate,Toast.LENGTH_SHORT).show();

    }
    public void showDatePickerDiaog(){
        datePicker newFragment=new datePicker();
        newFragment.show(getSupportFragmentManager(),"Date Picker");
    }

    public void updateTime(int hourOfDay, int minute) {
        String formattedTime = String.format(Locale.US,"%02d:%02d",hourOfDay,minute);
        selectedTime.setText("Time: "+formattedTime);
        Toast.makeText(this, formattedTime, Toast.LENGTH_SHORT).show();
    }

    public void sendmail(String Subject, String content, String to_email){
        Intent intent = new Intent(new Intent(Intent.ACTION_SEND));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to_email});
        intent.putExtra(Intent.EXTRA_SUBJECT, Subject);
        intent.putExtra(Intent.EXTRA_TEXT, content);
        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "Choose email Client: "));
    }
}