package com.example.studentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class TutorDashboard extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    NavigationView navigationView;
    Button tutorResourceBtn, paymentBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_dashboard);

        tutorResourceBtn = (Button) findViewById(R.id.tutorresourceButton);
        paymentBtn = (Button) findViewById(R.id.Paymentbutton);

        paymentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TutorDashboard.this, TutorPayment.class);
                startActivity(intent);
            }
        });

        tutorResourceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TutorDashboard.this, TutorResources.class);
                startActivity(intent);
            }
        });

        drawerLayout = findViewById(R.id.drawerLayout_tutor);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView_Tut_Dashboard);


        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.open();
            }
        });

        View headerView = navigationView.getHeaderView(0);
        ImageView useImage = headerView.findViewById(R.id.userImage);

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.navHome) {
                    Intent intetn = new Intent(getApplicationContext(), TutorDashboard.class);
                    startActivity(intetn);
                    Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navResources) {
                     Intent intetn = new Intent(getApplicationContext(), TutorResources.class);
                    startActivity(intetn);
                    Toast.makeText(getApplicationContext(), "Tutor Resources", Toast.LENGTH_SHORT).show();
                }
                if (itemId == R.id.navPayment) {
                    Intent intetn = new Intent(getApplicationContext(), TutorPayment.class);
                    startActivity(intetn);
                    Toast.makeText(getApplicationContext(), "Tutor Payment", Toast.LENGTH_SHORT).show();
                }
//                if (itemId == R.id.navFeedback) {
//                    Toast.makeText(getApplicationContext(), "Feedback", Toast.LENGTH_SHORT).show();
//                }

                if (itemId == R.id.navlogout) {
                    Intent intetn = new Intent(getApplicationContext(), Loginpage.class);
                    startActivity(intetn);
                    Toast.makeText(getApplicationContext(), "Logged out", Toast.LENGTH_SHORT).show();
                }

                drawerLayout.close();
                return false;
            }
        });
    }
}